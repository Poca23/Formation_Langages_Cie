const firstname = "Michel";
const lastname = "Polnareff";
let age = 123;
const isUserLoggedIn = false;
const account = undefined;
let account2;
const myVar = null;
const user = {
    firstname: "Michel",
    lastname: "Polnareff",
    email: "mich-mich@pol.com"
}
const colors = ['red', 'blue', 'green'];
const onSayHello = function sayHello() {
    return 'Hello';
}

/**
   * -------------------------------------------------------
   * 1 - Afficher le type de chacune des variables dans la console
   * -------------------------------------------------------
*/

