 /**
   * -------------------------------------------------------
   * 1 - Renommer les variables correctement
   * -------------------------------------------------------
*/

prénom = "Bruno";

let z = "Salut je m'appelle Bruno et voici ma description";

const métier = "Analyste financier au Yémen";

const age = 23;

l = "Bordeaux";

arr = "Une liste de nombres";

?? = "le prénom du plus grand agent secret de tous les temps";
